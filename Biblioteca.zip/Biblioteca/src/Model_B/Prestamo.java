/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model_B;




/**
 *
 * @author vina
 */
public class Prestamo {
    private int idPrestamo;
    private Libro libroPrestado;
    private Usuario usuario;
    private String fechaPrestamo;
    private String fechaDevolucion;
    private int tiempo_prestamo;
    
    public int calcularDiasPrestamo(){
        return  tiempo_prestamo = Integer.parseInt(fechaPrestamo)- Integer.parseInt(fechaDevolucion);

    }
    public void registrarDevolucion(){
        
    }
}
