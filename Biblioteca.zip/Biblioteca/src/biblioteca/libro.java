/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;


public class libro extends Material {
    private String autor;
    private String genero_libro;

    public libro() {
    }

    public libro(String autor, String genero_libro, String obtenerResumen, String idMaterial, String titulo) {
        super(idMaterial, titulo);
        this.autor = autor;
        this.genero_libro = genero_libro;
        this.obtenerResumen = obtenerResumen;
    }

    

   

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero_libro() {
        return genero_libro;
    }

    public void setGenero_libro(String genero_libro) {
        this.genero_libro = genero_libro;
    }
    
    private String obtenerResumen;
    
}
