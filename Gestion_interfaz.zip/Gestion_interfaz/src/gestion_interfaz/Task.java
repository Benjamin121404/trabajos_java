/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion_interfaz;

import java.util.Date;

/**
 *
 * @author vina
 */
public class Task {
    private int idTask;
    private String nombre;
    private Date fechaLimite;
    private int prioidad;
    private boolean completada;

    public Task() {
    }

    public Task(int idTask, String nombre, Date fechaLimite, int prioidad, boolean completada) {
        this.idTask = idTask;
        this.nombre = nombre;
        this.fechaLimite = fechaLimite;
        this.prioidad = prioidad;
        this.completada = completada;
    }

    public int getIdTask() {
        return idTask;
    }

    public void setIdTask(int idTask) {
        this.idTask = idTask;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(Date fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public int getPrioidad() {
        return prioidad;
    }

    public void setPrioidad(int prioidad) {
        this.prioidad = prioidad;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }
    
    
}
