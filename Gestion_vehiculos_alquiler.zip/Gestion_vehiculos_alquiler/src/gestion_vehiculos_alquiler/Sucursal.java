/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion_vehiculos_alquiler;

 import java.util.ArrayList;
public class Sucursal {
    private String idSucursal;
    private String nombre;
    private ArrayList<Vehiculo> vehiculosDisponibles = new ArrayList<>();

    public Sucursal() {
    }

    public Sucursal(String idSucursal, String nombre) {
        this.idSucursal = idSucursal;
        this.nombre = nombre;
    }

    public String getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(String idSucursal) {
        this.idSucursal = idSucursal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void agregarVehiculo(Vehiculo Vehiculo){
        vehiculosDisponibles.add(Vehiculo);
    } 
    
    
}
