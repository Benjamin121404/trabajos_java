/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion_vehiculos_alquiler;

/**
 *
 * @author vina
 */
public class VehiculoEstandar extends Vehiculo implements CostoAlquilerCalculable{

    public VehiculoEstandar(String idVehiculo, String modelo, Double costoBaseAlquiler) {
        super(idVehiculo, modelo, costoBaseAlquiler);
    }

    @Override
    public double calcularCostoAlquiler() {
        return this.getCostoBaseAlquiler();
    }
    
}
