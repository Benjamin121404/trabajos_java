
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaz_grafica;

/**
 *
 * @author vina
 */
public class Interfaz_grafica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Proyecto p = new Proyecto();
        Ventana v = new Ventana();
        v.setContentPane(new Inicio(p));
        v.setVisible(true);
        Task t = new Task();
    }
    
}
