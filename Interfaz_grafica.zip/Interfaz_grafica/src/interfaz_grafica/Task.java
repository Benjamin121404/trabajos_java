/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaz_grafica;

import java.util.Date;

/**
 *
 * @author vina
 */
public class Task {
    private int idTask;
    private String nombre;
    private Date fecha_limite;
    private int priotidad;
    private boolean completada;

    public Task() {
    }

    public Task(int idTask, String nombre, Date fecha_limite, int priotidad, boolean completada) {
        this.idTask = idTask;
        this.nombre = nombre;
        this.fecha_limite = fecha_limite;
        this.priotidad = priotidad;
        this.completada = completada;
    }

    public int getIdTask() {
        return idTask;
    }

    public void setIdTask(int idTask) {
        this.idTask = idTask;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha_limite() {
        return fecha_limite;
    }

    public void setFecha_limite(Date fecha_limite) {
        this.fecha_limite = fecha_limite;
    }

    public int getPriotidad() {
        return priotidad;
    }

    public void setPriotidad(int priotidad) {
        this.priotidad = priotidad;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }
    
    
}
