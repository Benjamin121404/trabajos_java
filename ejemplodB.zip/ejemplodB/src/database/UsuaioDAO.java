/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author vina
 */
public class UsuaioDAO {
    String leer = "SELECT * FROM usuarios;";
    
    public void insertar(Usuario usr){
        String guardar = ("INSERT INTO usuario(id,nombre,correo,pass) VALUES(?,?,?,?)");
        try{
            Connection conn = conexion.conectar();
            PreparedStatement ps = conn.prepareStatement(guardar);
            ps.setInt(1, usr.getId());
            ps.setString(2, usr.getNombre());
            ps.setString(3, usr.getCorreo());
            ps.setString(4, usr.getPass());
            ps.executeUpdate();
            System.out.println("usuario añadido con exito");
        }catch(Exception e){ 
            System.out.println("Error"+ e.getMessage());
        }
    }
    public List<Usuario> listar(){
        String leer = "SELECT * FROM usuario;";
        List<Usuario>lista = new ArrayList<>();
        try{
            Connection con = conexion.conectar();
            PreparedStatement ps = con.prepareStatement(leer);
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Usuario usr = new Usuario();
                usr.setId(res.getInt("id"));
                usr.setNombre(res.getString("nombre"));
                usr.setCorreo(res.getString("correo"));
                usr.setPass(res.getString("pass"));
                lista.add(usr);
                        
            }
        }catch(Exception e){
            System.out.println("Error"+ e.getMessage());
        }
       return lista;
    }
}
