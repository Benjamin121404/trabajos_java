/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
public class conexion {
    private static final String URL= "jdbc:mysql://localhost:3306/usuariosdb";
    private static final String USER= "root";
    private static final String PASS= "";
    
    private static Connection conn= null;
    
    public static Connection conectar(){
        try{
            if(conn == null|| conn.isClosed()){
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(URL,USER,PASS);
                System.out.println("Conexion exitosa");
            }
            
        }catch(Exception e){
            System.out.println("error "+ e.getMessage());
        }
         return conn;   
    }
    public static void cerrar(){
        try{
            if(conn != null &&  !conn.isClosed()){
                conn.close();
                System.out.println("Conexion cerrada");
                
            }
            
        }catch(Exception e){
            System.out.println("Error "+ e.getMessage());
        }
    }
}
