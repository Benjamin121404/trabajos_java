/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplodb;

import database.UsuaioDAO;
import database.conexion;
import java.util.List;
import model.Usuario;

/**
 *
 * @author vina
 */
public class EjemplodB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Usuario user1 = new Usuario("Alfonso","1234","eduardo.margarita@gmail.com",2);
        Usuario user2 = new Usuario("Criss","05-05","criss@gmail.com",3);
        UsuaioDAO usuarios = new UsuaioDAO();
        usuarios.insertar(user2);
        usuarios.insertar(user1);
       List<Usuario> lista = usuarios.listar();
       for(Usuario usr: lista){
           System.out.println(usr);
       }
       conexion.cerrar();
    }
    
}
